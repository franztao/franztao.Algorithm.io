
void getmidsolution(char * topo[MAX_EDGE_NUM], int line_num,char * filename,int *final_server);
